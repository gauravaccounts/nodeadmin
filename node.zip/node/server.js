var http = require("http");
var express = require('express');
var bodyParser=require('body-parser');
var session  = require('express-session');
var authenticateController=require('./controllers/authenticate-controller');
var registerController=require('./controllers/register-controller');
app = express();
app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());
app.use(function(req, res, next) { //allow cross origin requests
        res.setHeader("Access-Control-Allow-Methods", "POST, PUT, OPTIONS, DELETE, GET");
        res.header("Access-Control-Allow-Origin", "*");
        res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
          res.setHeader("Content-Type", "text/html")

        next();
    });
var user='';
app.use(session({secret:'367346347663'}));
/* route to handle login and registration */
app.post('/api/register',registerController.register);
app.post('/api/authenticate',authenticateController.authenticate);
app.engine('html', require('ejs').renderFile);
app.set('view engine', 'html');
app.use(express.static(__dirname + '/app'));
app.use(express.static(__dirname + '/node_modules'));
app.get('/',function(req,res)
{
	user = req.session;
	if(!user.email)
	{
		console.log('kk');
		res.sendFile(__dirname+'/app/template/admin/login.html');	
	}
	else
	{
		console.log('llll');
		res.redirect('/admin');
	}
})

var checkLogin = function(req,res,next)
{
	user = req.session;
	if(!user.email)
	{
		console.log('hiiiiiiiii');
		res.redirect('/');
	}
	next();
}
app.use(checkLogin);
app.all('/admin/', function(req, res) 
{
   res.sendFile(__dirname + '/app/template/admin/index.html');
});

httpServer = http.Server(express);
app.listen(8081);

/*create server */
// http.createServer(function (request, response) {
//    // Send the HTTP header 
//    // HTTP Status: 200 : OK
//    // Content Type: text/plain
//   // response.writeHead(200, {'Content-Type': 'text/plain'});
//    // Send the response body as "Hello World"
//   // response.end('Hello World\n');
// }).listen(8081);
// Console will print the message
console.log('Server running at http://127.0.0.1:8081/');
console.log('hi');