'use strict';
app.controller('adminCtrl',function($scope,$http,$window ,localStorageService,$location){
	 var config = {
            headers : {
                'Content-Type':  'application/json'
            }
        }
       /*Get all country list*/
       $scope.login = function()
       {
      		$scope.email  		= $scope.email;
      		$scope.password  	= $scope.password;
          var data ={email: $scope.email,
                  password:$scope.password
              };
          $http.post(api_path + "api/authenticate", data, config).success(function(responce) 
          {
            console.log(responce);
            if(responce.status==true)
            {
              $window.location.href = base_url+'admin';
                   $location.path('/admin');
             $location.replace();

            }
            // localStorageService.set('userid', responce.userid);
            // var userid =  localStorageService.get('id');
            // $location.path('/admin');
            // $location.replace();
            }).error(function() 
            {
            })
       }
     
});