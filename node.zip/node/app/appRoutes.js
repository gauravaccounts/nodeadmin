'use strict';
var app=angular.module("myApp",['ngRoute','ngSessionStorage','LocalStorageModule']);  
/* Define angular template path */
var TemplatePath = 'http://localhost:8081/template';
var api_path     = 'http://localhost:8081/';
var base_url     = 'http://localhost:8081/';
/*Difine routing */ 
app.config(function ($routeProvider,$locationProvider,localStorageServiceProvider) 
{
	  localStorageServiceProvider
    .setPrefix('nodeApp');

$routeProvider.when('/', {
        controller: 'adminCtrl',
        templateUrl:TemplatePath+'/dashboard.html'
    });
    $routeProvider.otherwise({ redirectTo: "/" });
    // $locationProvider.html5Mode(true);
    // $locationProvider.hashPrefix('');
})