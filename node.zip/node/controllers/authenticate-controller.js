var connection = require('./../config');
var Cryptr = require('cryptr'),
cryptr = new Cryptr('myTotalySecretKey');
module.exports.authenticate=function(req,res){
  user = req.session;
    var email=req.body.email;
    var password=req.body.password;
    var encryptedPass = cryptr.encrypt(password),
    decryptedPass = cryptr.decrypt(encryptedPass);
    connection.query('SELECT * FROM users WHERE email = ?',[email], function (error, results, fields) {
      if (error) {
          res.json({
            status:false,
            message:'there are some error with query'
            })
      }else{
        if(results.length >0){
            if(encryptedPass==results[0].password){
              user.email = email;
              user.id = results[0].id;
                res.json({
                    status:true,
                    userid:results[0].id,
                    message:'successfully authenticated'
                });
               // return res.status(301).redirect('/admin');
            }else{
                res.json({
                  status:false,
                  message:"Email and password does not match"
                 });
            }
         
        }
        else{
          res.json({
              status:false,    
            message:"Email does not exits"
          });
        }
      }
    });
}