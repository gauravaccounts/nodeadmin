@extends('app')

@section('css')
    @parent

    <link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">
    <link href="{{ asset('/css/chat.css') }}" rel="stylesheet">
    <script src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.3/moment.js"></script>
<script>
    if (!window.moment) { 
        document.write('<script src="assets/plugins/moment/moment.min.js"><\/script>');
    }
</script>
@endsection

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-9">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <span class="glyphicon glyphicon-comment"></span> Chat
                    <div class="btn-group pull-right">
                        <button type="button" class="btn btn-default btn-xs dropdown-toggle" data-toggle="dropdown">
                            <span class="glyphicon glyphicon-chevron-down"></span>
                        </button>

                        <ul class="dropdown-menu slidedown">
                            <li>
                                <span class="glyphicon glyphicon-ok-sign"></span>
                                Available
                            </li>

                            <li>
                                <span class="glyphicon glyphicon-remove"></span>
                                Busy
                            </li>

                            <li>
                                <span class="glyphicon glyphicon-time"></span>
                                Away
                            </li>

                            <li class="divider"></li>

                            <li>
                                <span class="glyphicon glyphicon-off"></span>
                                Sign Out
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="panel-body">
                    <ul class="chat">

                    </ul>
                </div>

                <div class="panel-footer">
                    <form id="send-message">
                        <div class="input-group">

                         <input id="message-input1" type="text" class="form-control input-sm" />

                            <input id="message-input" type="text" class="form-control input-sm" placeholder="Type your message here..." />

                            <span class="input-group-btn">
                                <button type="submit" class="btn btn-warning btn-sm" id="btn-chat">Send</button>
                            </span>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <ul class="chatUsers">

            </ul>
        </div>
    </div>
</div>
@endsection
@section('js')
    @parent

    <script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <script src="https://cdn.socket.io/socket.io-1.3.4.js"></script>

    <script>
        jQuery(function($) {
            var $messageForm = $('#send-message');
            var $messageBox = $('#message-input');
            var $chat = $('ul.chat');
            var $chatUsers = $('ul.chatUsers');
            var TYPING_TIMER_LENGTH = 3000; // ms
            var connected = false;

            // open a socket connection
            var socket = new io.connect('http://localhost:8080/', {
                'reconnection': true,
                'reconnectionDelay': 1000,
                'reconnectionDelayMax' : 5000,
                'reconnectionAttempts': 5
            });

            // when user connect, store the user id and name
            socket.on('connect', function (user) {
                socket.emit('join', {id: "<?= Auth::user()->id ?>", name: "<?= Auth::user()->name ?>"});
                //socket.emit('user joined');
            });
            // For typing and stop typing
             // Updates the typing event

          function updateTyping () {
              if (!typing) {
                typing = true;
                socket.emit('typing');
              }
              lastTypingTime = (new Date()).getTime();
              setTimeout(function () {
                var typingTimer = (new Date()).getTime();
                var timeDiff = typingTimer - lastTypingTime;
                if (timeDiff >= TYPING_TIMER_LENGTH && typing) {
                  socket.emit('stop typing');
                  typing = false;
                }
              }, TYPING_TIMER_LENGTH);
          }
          var $window = $(window);
                      $window.keydown(function (event) {
            // Auto-focus the current input when a key is typed
            // When the client hits ENTER on their keyboard
            if (event.which === 13) {
                socket.emit('stop typing');
                typing = false;
            }
          });
        $('#message-input').keyup(function(e) 
        {
            if(e.which===13)
            {
                socket.emit('stop typing');
                typing = false;
            }
            else
            {
                typing = true;
                socket.emit('typing', 'typing...');
                updateTyping();
            }
        });
        socket.on('typing', function(data) {
         
            if (data) {
                $('#message-input1').val(data.username+' is typing....');
            } else {
                $('#message-input1').val("");
            }
        });

             socket.on('stop typing', function (data) {
             
                if (data) {
                    //$('#message-input1').val(data.username+' is stop typing...');
                    $('#message-input1').val("");

                } else {
                    $('#message-input1').val("");
                }
            });
            $messageForm.on('submit', function (e) {
                e.preventDefault();
                if($messageBox.val()!='')
                {
                    socket.emit('chat.send.message', {msg: $messageBox.val(), nickname: '<?= Auth::user()->name ?>'});
                    $messageBox.val('');
                    socket.emit('stop typing');
                    typing = false;


                    socket.emit('send message', {
    room: '<?= Auth::user()->id ?>',
    message:  $messageBox.val()
});


                }
            });
            socket.on('conversation private post', function(data) {
                console.log('hiiinew')
    //display data.message
    console.log(data)
});
            socket.on('user joined',function(data)
            {
                console.log('User joined '+data.username);
            });
            socket.on('user left',function(data)
            {
                console.log('User has been left '+data.username);
            })
            // get connected users and display to all conected
            socket.on('chat.users', function (nicknames) {
                var html = '';
                $.each(nicknames, function (index, value) {
                    html += '<li><a href="' + value.socketId + '">' + value.nickname + '</a></li>';
                });

                $chatUsers.html(html);
            });
            // wait for a new message and append into each connection chat window
            socket.on('chat.message', function (data) 
            {
                data = JSON.parse(data);
                if(data.hasOwnProperty('system')) {
                    toastr["success"](data.msg);
                } else {
                    $chat.append(
                    '<li class="left clearfix">' +
                        '<span class="chat-img pull-left">' +
                           '<img src="http://placehold.it/50/55C1E7/fff&text=U" alt="User Avatar" class="img-circle" width="50" />' +
                        '</span>' +

                        '<div class="chat-body clearfix">' +
                            '<div class="header">' +
                                '<strong class="primary-font">' + data.nickname + '</strong>' +
                                '<small class="pull-right text-muted">' +
                                '<span class="glyphicon glyphicon-time"></span>' +
                                ' '+moment().calendar()+
                                '</small>' +
                            '</div>' +
                            '<p>' + data.msg + '</p>' +
                        '</div>' +
                    '</li>');
                }
            });
        });
    </script>
@endsection