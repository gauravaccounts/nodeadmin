<?php
class amazonApi {
	//private static $url;
	/*Get the Html code */
	public static function getHTMLcode($url) 
	{
			$curl = curl_init($url);
			curl_setopt($curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 10.10; labnol;) ctrlq.org");
			curl_setopt($curl, CURLOPT_FAILONERROR, true);
			curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
			$html = curl_exec($curl);
			curl_close($curl);
			return $html;
	}
	/*Get all the data */
	public static function getData($search)
	{
		$url="http://www.amazon.in/s/ref=nb_sb_noss/280-5472358-5762825?url=search-alias%3Daps&field-keywords=$search";
	    $html= self::getHTMLcode($url);
	    $image = '/<img src="(?P<img>[^"]*)"/';
	    preg_match_all($image,$html,$data);
	    $imgArray = $data[img];
	    array_shift($imgArray);
	    $title = '@data-attribute="(?P<val>[^"]+)"@';
	    preg_match_all($title,$html,$value);
	    $price ='/<span class="a-size-base a-color-price s-price a-text-bold"><span class="currencyINR">&nbsp;&nbsp;<\/span>(?P<price>[^>]*)<\/span>/';
	    preg_match_all($price,$html,$cost);
	     $amazon_data = Array(@$value[val], @$imgArray, @$cost[price]);
	   	$j=0;
		$amazonArray = Array();
		$amazon_title = Array();
		foreach ($amazon_data[0] as $x)
		{
			$amazonArray[$j]['amazon_title']=$x;
			$amazonArray[$j]['amazon_img']	=$amazon_data[1][$j];
			$amazonArray[$j]['amazon_price']=str_replace(',','',$amazon_data[2][$j]);
		    $amazon_title[$j] = $x;
		    $j++;
		    if($j>25){
				break;
		    }
		}
		usort($amazonArray, array('amazonApi','sortByPrice'));
		if(!empty($amazonArray))
		{
			$responce =json_encode(array('status'=>true,'data'=>$amazonArray,'message'=>'product list'));
			echo $responce;
		}
		else
		{
			$responce =json_encode(array('status'=>false,'message'=>'Record not found'));
			echo $responce;
		}
	}
	/*print the data in json formate*/
	public static function jsonData()
	{
		$title = $_POST['title'];
		$price = $_POST['price'];
		$image = $_POST['image'];
		$i=0;
		$response = Array();
		echo '{"products":[<br>';
		foreach($title as $a)
		{
			echo '{"title":"'.$title[$i].'", "price":"'.$price[$i].'", "image":"'.$image[$i].'"}';
			if(@$title[$i+1])
				echo ',<br>';
			$i++;
		}
		echo "<br>]}";
	}
	/*print the data in xml formate */
	public static function xmlData()
	{
		$title = $_POST['title'];
		$price = $_POST['price'];
		$image = $_POST['image'];
		$i=0;
		$response = Array();
		echo '&lt;products&gt;<br><br>';
		foreach($title as $a)
		{
			echo '&lt;product&gt;<br>&lt;title&gt;'.$title[$i].'&lt;/title&gt;<br>&lt;price&gt;'.$price[$i].'&lt;/price&gt;<br>&lt;image&gt;'.$image[$i].'&lt;/image&gt;<br>&lt;/product&gt;';
			if(@$title[$i+1])
				echo '<br><br>';
			$i++;
		}
		echo "<br><br>&lt;/products&gt;";
	}
	/*Sort the data by price */
	public static function sortByPrice($a, $b)
	{
	    $a = $a['amazon_price'];
	    $b = $b['amazon_price'];
	    if ($a == $b) return 0;
	    return ($a < $b) ? -1 : 1;
	}
}
if($_POST)
	{
		$search = $_POST['search']?$_POST['search']:'';
		$obj = new amazonApi();
		$type = $_POST['submit']?$_POST['submit']:$search;
		//$amazon_data = $obj->getData($search);
		switch($type){
		    case "Download json":
		       $amazon_data = $obj->jsonData();
		        break;
		    case "Download xml":
		       $amazon_data = $obj->xmlData();
		        break;
		    default:
		       $amazon_data = $obj->getData($search);
		}
	}
?>