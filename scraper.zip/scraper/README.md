# scraper
Scraper in PHP that using cURL. Scraps flipkart and amazon and can export as JSON or XML

This is a PHP script to scrap data from flipkart and amazon. Scraping data is not legal or advised. This is just for
educational purpose.

Clone the repository in your html folder if you are using apache. If you are using XAMPP, clone it in your htdocs directory.

Now, run your local server and open http://localhost/scraper/display.php in your browser. You will see a search bar,
search for items you want to fetch like "mobile".

You can download JSON and XML by clicking on the buttons provided.
