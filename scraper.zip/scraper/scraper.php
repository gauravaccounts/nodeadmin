<head>
	<link rel = "stylesheet" href = "style.css">
</head>

<?php
//INCLUDED FILES
include_once "amazon.php";
echo "<center>";
include "search.htm";
echo "</center>";

//INITIALIZED ARRAYS FOR DATA, TITLE, IMAGE AND PRICE
$amazon_data = Array();
$amazon_title = Array();
$amazon_img = Array();
$amazon_price = Array();

//IF SEARCH IS NOT FETCHED THROUGH GET METHOD, KILL REST OF THE PAGE (USED WHEN THE PAGE IS OPENED INITIALLY)
if(!isset($_GET['search']))
	die();
//CALLED FUNCTIONS THAT FETCH HTML CODE FROM RESPECTIVE SITES.
$amazon_data = amazon($_GET['search']);
//STORING DATA IN VARIABLES FOR AMAZON
$j=0;
foreach ($amazon_data[0] as $x)
{
    $amazon_title[$j] = $x;
    $j++;
    if($j>19)
		break;
}
$j=0;
foreach (@$amazon_data[1] as $x)
{
    $amazon_img[$j] = $x;
    $j++;
    if($j>19)
		break;
}
$j=0;
foreach ($amazon_data[2] as $x)
{
    $amazon_price[$j] = $x;
    $j++;
    if($j>19)
		break;
}
echo "</center></div>";
//DISPLAYING RESULTS FOR AMAZON
$j=0;
echo "<div class = 'main_div' style = 'float: right;'><center>";
echo "AMAZON";
foreach ($amazon_title as $x)
{
    echo "<div class = 'product'>";
    echo "<img src = '".@$amazon_img[$j]."' style = 'width: 190px; height: 200px;'><br>";
    echo @$x."<br>";
    echo "<div class = 'price'>".@$amazon_price[$j]."</div>";
    echo "</div>";
    $j++;
}
$a = ['json', 'xml'];
foreach($a as $x)
{
    echo "<form action = '$x.php' method = 'POST' target = '_blank'>";
    for($i=0; $i<20; $i++)
    {
    	echo "<input type = 'hidden' name = 'title[]' value = '$amazon_title[$i]'>";
    	echo "<input type = 'hidden' name = 'price[]' value = '$amazon_price[$i]'>";
    	echo "<input type = 'hidden' name = 'image[]' value = '$amazon_img[$i]'>";
    }
    echo "<input type = 'submit' value = 'Download $x'>
    </form>";
}
echo "</center></div>";
?>
