<?php
class amazonApi {
	//private static $url;
	/*Get the Html code */
	public static function getHTMLcode($url) 
	{
			$curl = curl_init($url);
			curl_setopt($curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 10.10; labnol;) ctrlq.org");
			curl_setopt($curl, CURLOPT_FAILONERROR, true);
			curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
			$html = curl_exec($curl);
			curl_close($curl);
			return $html;
	}
	public static function getData($search)
	{
		$url="http://www.amazon.in/s/ref=nb_sb_noss/280-5472358-5762825?url=search-alias%3Daps&field-keywords=$search";
	    $html= self::getHTMLcode($url);
	    $image = '/<img src="(?P<img>[^"]*)"/';
	    preg_match_all($image,$html,$data);
	    $imgArray = $data[img];
	    array_shift($imgArray);
	    $title = '@data-attribute="(?P<val>[^"]+)"@';
	    preg_match_all($title,$html,$value);
	    $price ='/<span class="a-size-base a-color-price s-price a-text-bold"><span class="currencyINR">&nbsp;&nbsp;<\/span>(?P<price>[^>]*)<\/span>/';
	    preg_match_all($price,$html,$cost);
	   return  $amazonArray = Array(@$value[val], @$imgArray, @$cost[price]);
	}
	public static function sortByPrice($a, $b)
	{
	    $a = $a['amazon_price'];
	    $b = $b['amazon_price'];
	    if ($a == $b) return 0;
	    return ($a < $b) ? -1 : 1;
	}
}
if($_POST)
	{
		$search = $_POST['search'];
		$obj = new amazonApi();
		$amazon_data = $obj->getData($search);
		$j=0;
		$amazonArray = Array();
		$amazon_title = Array();
		foreach ($amazon_data[0] as $x)
		{
			$amazonArray[$j]['amazon_title']=$x;
			$amazonArray[$j]['amazon_img']	=$amazon_data[1][$j];
			$amazonArray[$j]['amazon_price']=str_replace(',','',$amazon_data[2][$j]);
		    $amazon_title[$j] = $x;
		    $j++;
		    if($j>19){
				break;
		    }
		}
		usort($amazonArray, array('amazonApi','sortByPrice'));
		$responce =json_encode($amazonArray);
		echo $responce;
	}

?>