<!DOCTYPE html>
<html>
<head><script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<link rel = "stylesheet" href = "style.css">
</head>
<body>
<h2>Search Amazon Record</h2>
<form action="">
<!-- <select name="category" id = "category">
	<option value="vivo">Vivo</option>
	<option value="lenove">Lenovo</option>
	<option value="oppo">Oppo</option>
</select> -->
  <input type="text" name="search" id="search" value="" placeholder="Search product">
  <input type="button" value="Submit" id="amazon">
</form> 
<dir>
<table border="1px">
<tbody>
<div class = 'main_div' style = 'float: right;'><center>
<div id="product">	
</div>
<div id="data" ></div>
</center></div>	
</tbody>
</table>
</dir>
</body>
</html>
<script type="text/javascript">
$(document).ready(function() {
/*Search by Type */
$("#amazon").click(function(){
       	var search = $('#search').val();
       	var dataObj = {
       		search:search,
       	}
       	var queryStr = $.param(dataObj);
       	$.ajax({
			  type: "POST",
			  url: "amazonApiClass.php",
			  data: queryStr,
			  success: function(data){
			 
			    var productArray = JSON.parse(data);
			    console.log(productArray);
				var html = "";
				var i;
				for (i = 0; i < productArray.length; i++) {
					html+= '<div class = "product"><img src = '+productArray[i].amazon_img+' style = "width: 190px; height: 200px;"><br>'+productArray[i].amazon_title+'<br><div class = "price">'+productArray[i].amazon_price+'</div></div>';
				}
				var formHtml = "";
				$.each(['json','xml' ], function( index, value ) 
				{
					formHtml+= '<form action = "'+value+'.php" method = "POST"  target = "_blank">'
					for(m=0;m<20;m++)
					{
						formHtml+='<input type = "hidden" name = "title[]" value = "'+productArray[m].amazon_title+'"><input type = "hidden" name = "price[]" value = "'+productArray[m].amazon_price+'"><input type = "hidden" name = "image[]" value = "'+productArray[m].amazon_img+'">'
					}
					formHtml+= '<input type = "submit" value = "Download '+value+'"></form>'
				});
				$('#data').html(formHtml);
			    $('#product').html(html);
			  }
			});
    });
});
</script>