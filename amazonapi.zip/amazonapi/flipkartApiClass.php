<?php
class flipkartApi {
    private static $affiliateID;
    private static $token;
    private static $timeout = 45; 
    public function __construct($affiliateID, $token) 
     {
       self::$affiliateID = $affiliateID;
       self::$token = $token;
      }
      public static function getData($url, $dataType) {
         try {
         	  if(!isset($url) && !empty($url)) {
         		throw new exception("URL is not available.");
         	}
         	if(!isset($dataType) && !empty($dataType)) {
         		throw new exception("Please set datatype json or xml");
         	}
 
         	if (!function_exists('curl_init')){
                throw new exception("Curl is not available.");
         	}
         	 // Set header to make authentication
	        $headers = array(
	            'Cache-Control: no-cache',
	            'Fk-Affiliate-Id: '.self::$affiliateID,
	            'Fk-Affiliate-Token: '.self::$token
	            );
	        $cObj = curl_init();
	        curl_setopt($cObj, CURLOPT_URL, $url);
	        curl_setopt($cObj, CURLOPT_HTTPHEADER, $headers);
	        curl_setopt($cObj, CURLOPT_TIMEOUT, self::$timeout);
	        curl_setopt($cObj, CURLOPT_RETURNTRANSFER, TRUE);
	        $result = curl_exec($cObj);
	        curl_close($cObj);
             // render result as per format.
             if($dataType == 'json') {
               return $result ? json_decode($result, true) : false;
             } else if($dataType == 'xml') {
                return $result ? new SimpleXMLElement($result) : false;
             } else {
             	return false;
             }
 
         }  catch (Exception $e) {
            return $e->getMessage();
         }
      }
    public static function getUrl($data)
      {
        if(isset($data['category']))
        {
            $mobilecat = $data['category'];
            $urlEncode = 'q=mobile-phones-store?otracker=nmenu_sub_Electronics_0_Mobiles';
            switch ($mobilecat) {
                case "vivo":
                      $urlEncode = 'q=vivo-mobile-phones-store?otracker=nmenu_sub_Electronics_0_Vivo';
                    break;
                case "lenove":
                      $urlEncode = 'q=lenovo-mobile-phones-store?otracker=nmenu_sub_Electronics_0_Lenovo';
                    break;
                case "oppo":
                     $urlEncode = 'q=oppo-mobile-phones-store?otracker=nmenu_sub_Electronics_0_OPPO';
                    break;
                default:
                $urlEncode = 'q=mobile-phones-store?otracker=nmenu_sub_Electronics_0_Mobiles';
            }
        }
        else
        {
            $urlEncode = '';
            $search  = $data['search'];
            if($search)
            {
                $urlEncode = "q=$search";
            }
        }
        $offerJsonURL = 'https://affiliate-api.flipkart.net/affiliate/search/json?query='.$urlEncode.'&resultCount=10';
        return $offerJsonURL;
      }
 }

?>