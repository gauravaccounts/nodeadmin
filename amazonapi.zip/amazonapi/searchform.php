<!DOCTYPE html>
<html>
<head><script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>
<body>
<h2>Search FlipKart Record</h2>
<form action="">
<select name="category" id = "category">
	<option value="vivo">Vivo</option>
	<option value="lenove">Lenovo</option>
	<option value="oppo">Oppo</option>
</select>
  <input type="text" name="search" id="search" value="" placeholder="Search for product">
  <input type="button" value="Submit" id="flipkart">
</form> 
<dir>
	<span id="responce"></span>
</dir>

</body>
</html>
<script type="text/javascript">
$(document).ready(function() {
	 	var category = $('#category').val();
       	var dataObj = {
       		category:category,
       	}
       	var queryStr = $.param(dataObj);
       	$.ajax({
			  type: "POST",
			  url: "flipkart.php",
			  data: queryStr,
			  success: function(data){
			    $('#responce').html(data);
			  }
			});

$("#category").change(function(){
       	var category = $('#category').val();
       	var dataObj = {
       		category:category,
       	}
       	var queryStr = $.param(dataObj);
       	$.ajax({
			  type: "POST",
			  url: "flipkart.php",
			  data: queryStr,
			  success: function(data){
			    $('#responce').html(data);
			  }
			});
    });
$("#flipkart").click(function(){
       	var search = $('#search').val();
       	var dataObj = {
       		search:search,
       	}
       	var queryStr = $.param(dataObj);
       	$.ajax({
			  type: "POST",
			  url: "flipkart.php",
			  data: queryStr,
			  success: function(data){
			    $('#responce').html(data);
			  }
			});
    });
});
</script>