<?php 
include_once("flipkartApiClass.php"); 
// Get affiliateID and token from https://affiliate.flipkart.com/
// Set flipkart affiliateID and token
$affiliateID = 'gauravluc';
$token = '0adf56eb146a4353ae8ac4f6ea2f63ce';
$fkObj = new flipkartApi($affiliateID, $token);
$offerJsonURL = 'https://affiliate-api.flipkart.net/affiliate/offers/v1/top/json';
if($_POST)
{
	$offerJsonURL = flipkartApi::getUrl($_POST);
}
$prductlist = flipkartApi::getData($offerJsonURL,'json');
$productList = array();
$i = 0;
foreach ($prductlist['products'] as $key => $value){
	$productList[$i]['name']= $value['productBaseInfo']['productAttributes']['title'];
	$productList[$i]['productUrl']= $value['productBaseInfo']['productAttributes']['productUrl'];
	$productList[$i]['price']= $value['productBaseInfo']['productAttributes']['sellingPrice']['amount'];
	$productList[$i]['currency']= $value['productBaseInfo']['productAttributes']['sellingPrice']['currency'];
	$productList[$i]['discountPercentage']= $value['productBaseInfo']['productAttributes']['discountPercentage'];
	$productList[$i]['cashBack']= $value['productBaseInfo']['productAttributes']['cashBack'];
	$i++;	
}
function sortByPrice($a, $b)
{
    $a = $a['price'];
    $b = $b['price'];
    if ($a == $b) return 0;
    return ($a < $b) ? -1 : 1;
}
usort($productList, 'sortByPrice');
echo json_encode($productList);
?>