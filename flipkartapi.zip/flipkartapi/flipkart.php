<?php 
include_once("flipkartApiClass.php"); 
// Get affiliateID and token from https://affiliate.flipkart.com/
// Set flipkart affiliateID and token
	$affiliateID = 'gauravluc';
	$token = '0adf56eb146a4353ae8ac4f6ea2f63ce';
	$fkObj = new flipkartApi($affiliateID, $token);
	/*Set Default URL */
	$offerJsonURL = 'https://affiliate-api.flipkart.net/affiliate/offers/v1/top/json';
	/*If the Data is send by post */
	if($_POST)
	{
		$offerJsonURL = flipkartApi::getUrl($_POST);
	}
	/*Call Get data Method and pass url and data type json */
	$prductlist = flipkartApi::getData($offerJsonURL,'json');
	$productList = array();/*Initialize the blank product data */
	$i = 0;
	foreach ($prductlist['products'] as $key => $value)
	{
		$productList[$i]['name']= $value['productBaseInfo']['productAttributes']['title'];
		$productList[$i]['productUrl']= $value['productBaseInfo']['productAttributes']['productUrl'];
		$productList[$i]['price']= $value['productBaseInfo']['productAttributes']['sellingPrice']['amount'];
		$productList[$i]['currency']= $value['productBaseInfo']['productAttributes']['sellingPrice']['currency'];
		$productList[$i]['discountPercentage']= $value['productBaseInfo']['productAttributes']['discountPercentage'].'%';
		$productList[$i]['cashBack']= $value['productBaseInfo']['productAttributes']['cashBack'];
		$i++;	
	}
	/*Sort data by price */
	function sortByPrice($a, $b)
	{
	    $a = $a['price'];
	    $b = $b['price'];
	    if ($a == $b) return 0;
	    return ($a < $b) ? -1 : 1;
	}
	usort($productList, 'sortByPrice');
	/*Apend the data in file */
	 $myfile = fopen("responce.json", "a") or die("Unable to open file!");
	 $responce =json_encode($productList);
	 $responce = '[{"name": "iPhone 6S", "productUrl": "http://s3.amazonaws.com/image1.jpg", "price" : "233 USD", "currency" : "INR", "discountPercentage" : "21%","cashBack":"10" },{"name": "iPhone 6S", "productUrl": "http://s3.amazonaws.com/image1.jpg", "price" : "233 USD", "currency" : "INR", "discountPercentage" : "21%","cashBack":"10" }]';
	fwrite($myfile, "\n".$responce);/*Save the responce data in file */
	fclose($myfile);
	echo $responce;
?>