<!DOCTYPE html>
<html>
<head><script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>
<body>
<h2>Search FlipKart Record</h2>
<form action="">
<select name="category" id = "category">
	<option value="vivo">Vivo</option>
	<option value="lenove">Lenovo</option>
	<option value="oppo">Oppo</option>
</select>
  <input type="text" name="search" id="search" value="" placeholder="Search for product">
  <input type="button" value="Submit" id="flipkart">
</form> 
<dir>
<table border="1px">
<thead>
	<tr>
		<th>Name</th>
		<th>ProductUrl</th>
		<th>Price</th>
		<th>Currency</th>
		<th>DiscountPercentage</th>
		<th>CashBack</th>
	</tr>
	</thead>
	<tbody id="responce">

	</tbody>
</tbody></table>
</dir>
</body>
</html>
<script type="text/javascript">
$(document).ready(function() {
	 	var category = $('#category').val();
       	var dataObj = {
       		category:category,
       	}
       	var queryStr = $.param(dataObj);
       	$.ajax({
			  type: "POST",
			  url: "flipkart.php",
			  data: queryStr,
			  success: function(data){
			  	/*Responce data */
				var productArray = JSON.parse(data);
				var html = "";
				var i;
				for (i = 0; i < productArray.length; i++) {
				    html += '<tr><td>'+productArray[i].name+'</td><td>'+productArray[i].productUrl+'</td><td>'+productArray[i].price+'</td><td>'+productArray[i].currency+'</td><td>'+productArray[i].discountPercentage+'</td><td>'+productArray[i].cashBack+'</td></tr>';
				}
			    $('#responce').html(html);
			  }
			});
/*Search by category */
$("#category").change(function(){
       	var category = $('#category').val();
       	var dataObj = {
       		category:category,
       	}
       	var queryStr = $.param(dataObj);
       	$.ajax({
			  type: "POST",
			  url: "flipkart.php",
			  data: queryStr,
			  success: function(data){
			    var productArray = JSON.parse(data);
				var html = "";
				var i;
				for (i = 0; i < productArray.length; i++) {
				    html += '<tr><td>'+productArray[i].name+'</td><td>'+productArray[i].productUrl+'</td><td>'+productArray[i].price+'</td><td>'+productArray[i].currency+'</td><td>'+productArray[i].discountPercentage+'</td><td>'+productArray[i].cashBack+'</td></tr>';
				}
			    $('#responce').html(html);
			  }
			});
    });
/*Search by Type */
$("#flipkart").click(function(){
       	var search = $('#search').val();
       	var dataObj = {
       		search:search,
       	}
       	var queryStr = $.param(dataObj);
       	$.ajax({
			  type: "POST",
			  url: "flipkart.php",
			  data: queryStr,
			  success: function(data){
			    var productArray = JSON.parse(data);
				var html = "";
				var i;
				for (i = 0; i < productArray.length; i++) {
				    html += '<tr><td>'+productArray[i].name+'</td><td>'+productArray[i].productUrl+'</td><td>'+productArray[i].price+'</td><td>'+productArray[i].currency+'</td><td>'+productArray[i].discountPercentage+'</td><td>'+productArray[i].cashBack+'</td></tr>';
				}
			    $('#responce').html(html);
			  }
			});
    });
});
</script>